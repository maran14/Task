<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\Models\ItemValue; // Adjust the namespace as per your project structure.

class Item extends Model
{
    protected $table = 'item';
    protected $fillable = ['form_id', 'task', 'status'];

    public function form()
    {
        return $this->belongsTo(Form::class);
    }

    public function itemValues()
    {
        return $this->hasMany(ItemValue::class);
    }
}
