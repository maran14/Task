<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\Models\Item; // Adjust the namespace as per your project structure.

class ItemValue extends Model
{
    protected $table = 'item_value';
    protected $fillable = ['form_id', 'item_id', 'value'];

    public function item()
    {
        return $this->belongsTo(Item::class);
    }
}
