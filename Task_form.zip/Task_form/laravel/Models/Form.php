<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\Models\Item; // Adjust the namespace as per your project structure.

class Form extends Model
{
    protected $table = 'form';
    protected $fillable = ['name', 'url'];
    
    public function items()
    {
        return $this->hasMany(Item::class);
    }
}
