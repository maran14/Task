<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Form;



class FormController extends Controller
{
    public function store(Request $request)
    {
        $data = $request->json()->all();
        $form = Form::create([
            'name' => $data['projectName'],
            'url' => $data['url'],
        ]);

        foreach ($data['morningTask'] as $taskData) {
            $item = $form->items()->create([
                'task' => $taskData['task'],
                'status' => $taskData['status'],
            ]);

            $item->itemValues()->create([
                'value' => $taskData['Details'],
            ]);
        }

        foreach ($data['afternoonTask'] as $taskData) {
            $item = $form->items()->create([
                'task' => $taskData['task'],
                'status' => $taskData['status'],
            ]);

            $item->itemValues()->create([
                'value' => $taskData['Details'],
            ]);
        }

        return response()->json(['message' => 'Data saved successfully']);
    }
}
