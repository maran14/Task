-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2023 at 12:16 AM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 7.4.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `form`
--

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `form`
--

CREATE TABLE `form` (
  `id` int(50) NOT NULL,
  `name` text NOT NULL,
  `url` varchar(100) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `form`
--

INSERT INTO `form` (`id`, `name`, `url`, `created_at`, `updated_at`) VALUES
(1, 'projectName', 'mayura office', '2023-10-29 17:30:45.000000', '2023-10-29 17:30:45.000000'),
(3, 'projectName1', 'mayura office1', '2023-10-29 17:36:24.000000', '2023-10-29 17:36:24.000000'),
(4, 'projectName2', 'mayura office2', '2023-10-29 17:36:58.000000', '2023-10-29 17:36:58.000000');

-- --------------------------------------------------------

--
-- Table structure for table `item`
--

CREATE TABLE `item` (
  `id` int(50) NOT NULL,
  `form_id` int(50) NOT NULL,
  `task` varchar(50) NOT NULL,
  `status` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `item_value`
--

CREATE TABLE `item_value` (
  `id` int(50) NOT NULL,
  `form_master_id` int(50) NOT NULL,
  `item_id` int(50) NOT NULL,
  `value` varchar(250) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT current_timestamp(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

CREATE TABLE `password_resets` (
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_access_tokens`
--

INSERT INTO `personal_access_tokens` (`id`, `tokenable_type`, `tokenable_id`, `name`, `token`, `abilities`, `last_used_at`, `created_at`, `updated_at`) VALUES
(1, 'App\\Models\\User', 1, 'Myapp', '565518804803ddc242b4966f06de73cf80080c9531884a089bb7d5a51ba1f3fb', '[\"*\"]', NULL, '2023-10-27 14:59:48', '2023-10-27 14:59:48'),
(2, 'App\\Models\\User', 1, 'Myapp', '771dcc2690ad4b9cb0c1ead60c95c235f5677bfa2db48cb325381de59ecfa231', '[\"*\"]', NULL, '2023-10-27 15:22:24', '2023-10-27 15:22:24'),
(3, 'App\\Models\\User', 1, 'Myapp', '87b7a1355294c40a26b8d7f4f3c73e41eae8a0adb262c5e7dc8e6bc1b1204c38', '[\"*\"]', NULL, '2023-10-27 15:23:55', '2023-10-27 15:23:55'),
(4, 'App\\Models\\User', 2, 'Myapp', 'e3ba381625f3cfca9a44b3f495304f336c2f79f8e99042a5bfea9f50f20b7107', '[\"*\"]', NULL, '2023-10-27 15:31:08', '2023-10-27 15:31:08'),
(5, 'App\\Models\\User', 2, 'Myapp', '8328f3bb1514a7ad7a38a0b837a5cb885081551c224a74aec2a2b22aaac57da9', '[\"*\"]', NULL, '2023-10-27 15:33:01', '2023-10-27 15:33:01'),
(6, 'App\\Models\\User', 4, 'Myapp', '5ad24a196bc29319512487a4d808e268d04932207273e0296ca34210d772bbce', '[\"*\"]', NULL, '2023-10-29 09:25:37', '2023-10-29 09:25:37'),
(7, 'App\\Models\\User', 4, 'Myapp', '46dfd91e47ab85eb2c53e1c014aea61413b333af36ae20f4ecab3f1d2cbee6d6', '[\"*\"]', NULL, '2023-10-29 09:26:31', '2023-10-29 09:26:31'),
(8, 'App\\Models\\User', 5, 'Myapp', '0341e0e00882b61891db3aa9e538f2d452179be40c480922b475d4cc88a766d9', '[\"*\"]', NULL, '2023-10-29 11:53:49', '2023-10-29 11:53:49'),
(9, 'App\\Models\\User', 7, 'Myapp', '3c808802801841afca81682b49be5e78ec7a8258de464819a4eed90b2598e3a8', '[\"*\"]', NULL, '2023-10-29 11:57:10', '2023-10-29 11:57:10'),
(10, 'App\\Models\\User', 8, 'Myapp', '49ca9eea6efbc8b1d19eebd8f7cd16ce263c24de53522a987929fd80fd9a4ee6', '[\"*\"]', NULL, '2023-10-29 12:12:04', '2023-10-29 12:12:04'),
(11, 'App\\Models\\User', 4, 'Myapp', '185e142a10e980b573edbb18c4ba4957af3c5fb6583034db5e9a1ef08738f462', '[\"*\"]', NULL, '2023-10-29 12:16:22', '2023-10-29 12:16:22'),
(12, 'App\\Models\\User', 4, 'Myapp', '26017ebd9e7f66093877b8d17705178c692cbeca248aa494469b75835fe92432', '[\"*\"]', NULL, '2023-10-29 12:29:34', '2023-10-29 12:29:34'),
(13, 'App\\Models\\User', 4, 'Myapp', '00731862ece8b165d78276685f78a102156f678d1db0d6de736fd4a91c77e0d5', '[\"*\"]', NULL, '2023-10-29 13:02:25', '2023-10-29 13:02:25'),
(14, 'App\\Models\\User', 4, 'Myapp', '076f3ac4e60429d5bde2a913513ab9caed2a710bb33ebe2322b12a0efd7a45da', '[\"*\"]', NULL, '2023-10-29 13:03:00', '2023-10-29 13:03:00'),
(15, 'App\\Models\\User', 4, 'Myapp', 'd440b61cb3a130369f3a516619c6c7472ffb056c071c56348f17018ed926a1f1', '[\"*\"]', NULL, '2023-10-29 13:13:57', '2023-10-29 13:13:57');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'manimaran', 'manimaran@gmail.com', NULL, '$2y$10$vgyy0i/x/ux90iSQbxLfnOoqTfeLAOX3x/QGbB3jciAwOWRgxIEAu', NULL, '2023-10-27 14:59:48', '2023-10-27 14:59:48'),
(2, 'test', 'test@gmail.com', NULL, '$2y$10$rDJsBeXuU.3.nS.Df2/rbuMb4YSEMrHCu7zMG2Ix..j0W9U5EiDzW', NULL, '2023-10-27 15:31:08', '2023-10-27 15:31:08'),
(4, 'maran1', 'test1@gmail.com', NULL, '$2y$10$xc853okmOxdUogODTXl0Yexs/QyClU4SJUCb.v/yhv0/tFEZzpAne', NULL, '2023-10-29 09:25:37', '2023-10-29 09:25:37'),
(5, 'sdsdw', 'ASD@gmail.com', NULL, '$2y$10$.qhUyo1qGUsbp2OO50CBCuT20dskbw2mWcoO.CpzXHhwsSrKuSmMO', NULL, '2023-10-29 11:53:49', '2023-10-29 11:53:49'),
(7, 'rohit', 'rohit14@gmail.com', NULL, '$2y$10$RQX2IAmiyA8SUrwCmjArE.gp8Jndu3RhuX7/zgRYLWnxL/.GlVy1a', NULL, '2023-10-29 11:57:10', '2023-10-29 11:57:10'),
(8, 'adarsh', 'adarsh@gmail.com', NULL, '$2y$10$90Pn/xdpHomxnJNsMt7o0ej6ou9r6M3q1hBcDILtrNF/OjYtySEju', NULL, '2023-10-29 12:12:04', '2023-10-29 12:12:04');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `form`
--
ALTER TABLE `form`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`);

--
-- Indexes for table `item`
--
ALTER TABLE `item`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `item_value`
--
ALTER TABLE `item_value`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_resets`
--
ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `form`
--
ALTER TABLE `form`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `item`
--
ALTER TABLE `item`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `item_value`
--
ALTER TABLE `item_value`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
