import React from 'react';

import { useNavigate } from 'react-router-dom'; // Import useNavigate

import '../css/Login.css';

function Login() {

  const navigate = useNavigate(); // Initialize navigate

  // Function to navigate to the Signup page
  const goToSignup = () => {
    navigate('/Signup');
  };

  return (
    <div>
    <link rel="stylesheet" href="https://cdn.formbold.com/formbold.css" />
    <br />
    <div class="formbold-builder-form themeThree">
      <form
        enctype="multipart/form-data"
        action="https://formbold.com/s/oPaQ8"
        method="POST"
        class="mx-auto w-full max-w-[570px] rounded-[10px] border border-stroke bg-white p-10 themeThree"
      >
        <div class="SortableItem fb-builder-item">
          <h3
            class="static text-xl font-semibold leading-tight text-black sm:text-[28px]"
          >
            Login
          </h3>
        </div>
        <div class="SortableItem fb-builder-item">
          <div class="mb-4">
            <label class="mb-2.5 block text-base text-black"  ><span>E-Mail</span   ><span class="label-required pl-1 text-red-400">*</span></label   ><input
              type="email"
              class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="email_input_866A6B5E-AAA9-4173-B2BF-21FC3D7711BE"
              placeholder="Enter Email Address"
              required
            />
          </div>
        </div>
        <div class="SortableItem fb-builder-item">
          <div class="mb-4">
            <label class="mb-2.5 block text-base text-black"
              ><span>Password</span><span class="label-required pl-1 text-red-400">*</span></label ><input
              type="password"
              class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="text_input_818450A6-1A20-48EE-9AEC-0D2D474DE658"
              placeholder="Password"
              required
            />
          </div>
        </div>
        <div>
           Not a member?{' '}
           <a href="#" onClick={goToSignup}  style={{ fontWeight: 'bold', color: 'blue' }} >   Signup now </a>
        </div>
        <div class="btn-toolbar flex items-center space-x-3">
          <input
            type="submit"
            class="inline-flex cursor-pointer items-center justify-center rounded border border-primary bg-primary px-8 py-2 text-base font-medium text-white hover:bg-opacity-90"
            value="Submit"
          />
        </div>
      </form>
  
    </div>
  </div>
  );
}

export default Login;
