import React, { useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';
import '../css/Login.css';

function Login() {
  const navigate = useNavigate(); // Initialize navigate

    // Function to navigate to the Signup page
    const goToSignup = () => {
      navigate('/Signup');
    };

  const [formData, setFormData] = useState({
    email: '',
    password: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Make a POST request using Axios
    axios.post('http://127.0.0.1:8000/api/login', formData)
    .then(response => {
        // Handle the API response, e.g., display a success message
        alert("Login Successfully");

        // Navigate to the Register page after a successful login
        navigate('/Register');
      })
      .catch(error => {
        // Handle errors, e.g., display an error message
        console.error('API error:', error);
        alert("invalid credentials");
        window.location.reload(); 

      });
  };

  return (
    <div>
    <link rel="stylesheet" href="https://cdn.formbold.com/formbold.css" />
    <br />
    <div class="formbold-builder-form themeThree">
      <form
        // action="https://formbold.com/s/oPaQ8"
        // method="POST"
        onSubmit={handleSubmit} // Add onSubmit event handler
        class="mx-auto w-full max-w-[570px] rounded-[10px] border border-stroke bg-white p-10 themeThree"
      >
        <div class="SortableItem fb-builder-item">
          <h3
            class="static text-xl font-semibold leading-tight text-black sm:text-[28px]"
          >
            Login
          </h3>
        </div>
        <div class="SortableItem fb-builder-item">
          <div class="mb-4">
            <label class="mb-2.5 block text-base text-black"  ><span>E-Mail</span   ><span class="label-required pl-1 text-red-400">*</span></label   ><input
              type="email"
              class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="email"
              placeholder="Enter Email Address"
              required
              value={formData.email}
              onChange={handleInputChange}
            />
          </div>
        </div>
        <div class="SortableItem fb-builder-item">
          <div class="mb-4">
            <label class="mb-2.5 block text-base text-black"
              ><span>Password</span><span class="label-required pl-1 text-red-400">*</span></label ><input
              type="password"
              class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="password"
               placeholder="Password"
               required
               value={formData.password}
               onChange={handleInputChange}
            />
          </div>
        </div>
        <div>
           Not a member?{' '}
           <a href="#" onClick={goToSignup}  style={{ fontWeight: 'bold', color: 'blue' }} >   Signup now </a>
        </div>
        <div class="btn-toolbar flex items-center space-x-3">
          <input
            type="submit"
            class="inline-flex cursor-pointer items-center justify-center rounded border border-primary bg-primary px-8 py-2 text-base font-medium text-white hover:bg-opacity-90"
            value="Submit"
          />
        </div>
      </form>
  
    </div>
  </div>
  );
}

export default Login;
