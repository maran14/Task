import React, { useState } from 'react';
import axios from 'axios';

function Signup() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    password: ''
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Make a POST request using Axios
    axios.post('http://127.0.0.1:8000/api/register', formData)
    .then(response => {
        // Handle the API response, e.g., display a success message
        alert("signup successfully completed login now");
        window.location.reload(); // Reload the page on success

      })
      .catch(error => {
        // Handle errors, e.g., display an error message
        console.error('API error:', error);
        alert("error in signup");

      });
  };

  return (
    <div>
      <link rel="stylesheet" href="https://cdn.formbold.com/formbold.css" />
      <br />
      <div className="formbold-builder-form themeOne">
        <form
          onSubmit={handleSubmit} // Add onSubmit event handler
          className="mx-auto w-full max-w-[570px] rounded-[10px] border border-stroke bg-white p-10 themeOne"
        >
          <div className="SortableItem fb-builder-item">
            <h3 className="static !font-bold text-xl font-semibold leading-tight text-black sm:text-[28px]">
              Sign Up
            </h3>
          </div>
          <div className="SortableItem fb-builder-item">
            <div className="mb-4">
              <label className="mb-2.5 block text-base text-black">
                <span>Name</span>
                <span className="label-required pl-1 text-red-400">*</span>
              </label>
              <input
                type="text"
                className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
                name="name"
                placeholder="name"
                required
                value={formData.name}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <div className="SortableItem fb-builder-item">
            <div className="mb-4">
              <label className="mb-2.5 block text-base text-black">
                <span>E-Mail</span>
                <span className="label-required pl-1 text-red-400">*</span>
              </label>
              <input
                type="email"
                className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
                name="email"
                placeholder="Enter Email Address"
                required
                value={formData.email}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <div className="SortableItem fb-builder-item">
            <div className="mb-4">
              <label className="mb-2.5 block text-base text-black">
                <span>Password</span>
                <span className="label-required pl-1 text-red-400">*</span>
              </label>
              <input
                type="password"
                className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
                name="password"
                placeholder="Password"
                required
                value={formData.password}
                onChange={handleInputChange}
              />
            </div>
          </div>
          <div className="btn-toolbar flex items-center space-x-3">
            <input
               type="submit"
               onClick={handleSubmit} // Call handleSubmit when the button is clicked
               className="inline-flex cursor-pointer items-center justify-center rounded border border-primary bg-primary px-8 py-2 text-base font-medium text-white hover-bg-opacity-90"
               value="Submit"
            />
          </div>
        </form>
      </div>
    </div>
  );
}

export default Signup;
