import React from 'react';

function Signup() {
  return (
    <div>
    <link rel="stylesheet" href="https://cdn.formbold.com/formbold.css" />
    <br />
    <div className="formbold-builder-form themeOne">
      <form
        enctype="multipart/form-data"
        action="https://formbold.com/s/915er"
        method="POST"
        className="mx-auto w-full max-w-[570px] rounded-[10px] border border-stroke bg-white p-10 themeOne"
      >
        <div className="SortableItem fb-builder-item">
          <h3
            className="static !font-bold text-xl font-semibold leading-tight text-black sm:text-[28px]"
          >
            Sign Up
          </h3>
        </div>
        <div className="SortableItem fb-builder-item">
          <div className="mb-4">
            <label className="mb-2.5 block text-base text-black"
              ><span>Name</span ><span className="label-required pl-1 text-red-400">*</span></label ><input
              type="text"
              className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="text_input_1C23CFB1-F7D2-4C2F-9C2A-D0D316F36711"
              placeholder="name"
              required
            />
          </div>
        </div>
        <div className="SortableItem fb-builder-item">
          <div className="mb-4">
            <label className="mb-2.5 block text-base text-black"
              ><span>E-Mail</span><span className="label-required pl-1 text-red-400">*</span></label><input
              type="email"
              className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="email_input_666E8A8E-44BD-48A8-9D25-2C579B2E3225"
              placeholder="Enter Email Address"
              required
            />
          </div>
        </div>
        <div className="SortableItem fb-builder-item">
          <div className="mb-4">
            <label className="mb-2.5 block text-base text-black"
              ><span>Password</span ><span className="label-required pl-1 text-red-400">*</span></label><input type="password"
              className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="text_input_F00E7F3F-4908-4C70-B9A3-854FE2D34073"
              placeholder="Password"
              required
            />
          </div>
        </div>
        <div className="btn-toolbar flex items-center space-x-3">
          <input
            type="submit"
            className="inline-flex cursor-pointer items-center justify-center rounded border border-primary bg-primary px-8 py-2 text-base font-medium text-white hover:bg-opacity-90"
            value="Submit"
          />
        </div>
      </form>
    
    </div>
  </div>
  );
}

export default Signup;
