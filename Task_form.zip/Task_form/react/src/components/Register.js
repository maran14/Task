import React, { useState } from 'react';


import '../css/Login.css';

function Register() {

  const [formData, setFormData] = useState({
    projectName: '',
    morningTask: {
      taskDetails: '',
      status: 'Development-Done', // Set a default value
      Details: '',
    },
    afternoonTask: {
      taskDetails: '',
      status: 'Development-Done', // Set a default value
      Details: '',
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(JSON.stringify(formData, null, 2)); // Display data in JSON format
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleMorningTaskChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      morningTask: {
        ...prevData.morningTask,
        [name]: value,
      },
    }));
  };

  const handleAfternoonTaskChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      afternoonTask: {
        ...prevData.afternoonTask,
        [name]: value,
      },
    }));
  };



  return (
<div>
  <link rel="stylesheet" href="https://cdn.formbold.com/formbold.css" />
  <br />
  <div className="formbold-builder-form themeThree">
    <form
     onSubmit={handleSubmit}
      className="mx-auto w-full max-w-[570px] rounded-[10px] border border-stroke bg-white p-10 themeThree"
    >
      <div className="SortableItem fb-builder-item">
        <h3 className="static !font-bold text-xl font-semibold leading-tight text-black sm:text-[28px]">
          Project Management
        </h3>
      </div>
      <div className="SortableItem fb-builder-item">
        <div className="mb-4">
          <label className="mb-2.5 block text-base text-black" ><span>Project Name</span  ><span className="label-required pl-1 text-red-400">*</span></label  ><input
            type="text"
            className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
            name="projectName"
            placeholder="Project Name"
            value={formData.projectName}
            onChange={handleInputChange}


            required
          />
        </div>
      </div>
      <div className="SortableItem fb-builder-item">
  <div className="mb-4 flex">
  <div className="mr-4" style={{ marginRight: '10px' }}> 

    <label className="mb-2.5 block text-base text-black"><span>Morning Task</span><span className="label-required pl-1 text-red-400">*</span></label>
    <input 
    type="text" 
    className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
     name="taskDetails"
      placeholder="Task Details"
      value={formData.taskDetails}
      onChange={handleMorningTaskChange}

       required />
 
    </div>
    <div>
    <label className="mb-2.5 block text-base text-black"><span>Status</span><span className="label-required pl-1 text-red-400">*</span></label>
    <select
     className="w-full appearance-none rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
     name="status"
     value={formData.status}
     onChange={handleMorningTaskChange}

     >
      <option value="place_holder_option_1">Development-Done</option>
      <option value="processing">Processing</option>
    </select>
    </div>
  </div>
  </div>


      <div className="SortableItem fb-builder-item">
        <div className="mb-4">
          <label className="mb-2.5 block text-base text-black" ><span>Details</span   ><span className="label-required pl-1 text-red-400">*</span></label ><textarea
            className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
            name="Details"
            placeholder="Explain about morning section"
            value={formData.Details}
            onChange={handleMorningTaskChange}

            required
          ></textarea>
        </div>
      </div>

      <div className="SortableItem fb-builder-item">
  <div className="mb-4 flex">
  <div className="mr-4" style={{ marginRight: '10px' }}> 

    <label className="mb-2.5 block text-base text-black"><span>Afternoon Task</span><span className="label-required pl-1 text-red-400">*</span></label>
    <input 
    type="text" 
    className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
     name="taskDetails"
      placeholder="Task Details"
      value={formData.taskDetails}
      onChange={handleAfternoonTaskChange}

       required />
 
    </div>
    <div>
    <label className="mb-2.5 block text-base text-black"><span>Status</span><span className="label-required pl-1 text-red-400">*</span></label>
    <select 
    className="w-full appearance-none rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
     name="status"
     value={formData.status}
     onChange={handleAfternoonTaskChange}

     >
      <option value="place_holder_option_1">Development-Done</option>
      <option value="processing">Processing</option>
    </select>
    </div>
  </div>
  </div>
     
      <div className="SortableItem fb-builder-item">
        <div className="mb-4">
          <label className="mb-2.5 block text-base text-black"
            ><span>Details</span><span className="label-required pl-1 text-red-400">*</span></label><textarea
            className="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
            name="Details"
            placeholder="Explain about afternoon section"
            value={formData.Details}
            onChange={handleAfternoonTaskChange}

            required
          ></textarea>
        </div>
      </div>
      <div className="btn-toolbar flex items-center space-x-3">
        <input
          type="submit"
          className="inline-flex cursor-pointer items-center justify-center rounded border border-primary bg-primary px-8 py-2 text-base font-medium text-white hover-bg-opacity-90"
          value="Submit"
        />
      </div>
    </form>
   
  </div>
</div>
  );
}

export default Register;
