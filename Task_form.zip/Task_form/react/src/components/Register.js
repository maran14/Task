import React from 'react';


import '../css/Login.css';

function Register() {
  return (

    <div>
    <link rel="stylesheet" href="https://cdn.formbold.com/formbold.css" />
    <br />
    <div class="formbold-builder-form themeOne">
      <form
        enctype="multipart/form-data"
        action="https://formbold.com/s/9kxVl"
        method="POST"
        class="mx-auto w-full max-w-[570px] rounded-[10px] border border-stroke bg-white p-10 themeOne"
      >
        <div class="SortableItem fb-builder-item">
          <h3
            class="static italic text-xl font-semibold leading-tight text-black sm:text-[28px]"
          >
            Registration Form
          </h3>
        </div>
        <div class="SortableItem fb-builder-item">
          <div class="mb-4 flex"> 
            <div class="mr-4" style={{ marginRight: '10px' }}> 
              <label class="mb-2.5 block text-base text-black">
                <span>First Name</span>
                <span class="label-required pl-1 text-red-400">*</span>
              </label>
              <input
                type="text"
                class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
                name="text_input_88CD4B9F-43EF-486C-B8BB-4C1CF2E4F3BE"
                placeholder="First Name"
                required
              />
            </div>
            <div>
              <label class="mb-2.5 block text-base text-black">
                <span>Last Name</span>
              </label>
              <input
                type="text"
                class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus-border-primary"
                name="text_input_B05F3929-323A-454B-B97C-7E719A63B70B"
                placeholder="Last Name"
              />
            </div>
          </div>
        </div>
        
        <div class="SortableItem fb-builder-item">
          <div class="mb-4 flex">
            <div class="mr-4" style={{ marginRight: '10px' }}>
              <label class="mb-2.5 block text-base text-black">
                <span>Gender</span>
                <span class="label-required pl-1 text-red-400">*</span>
              </label>
              <select
                class="w-full appearance-none rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
                name="dropdown_7C5D115F-5DD2-4EE8-989B-2CABA3875219"
              >
                <option value="Male">Male</option>
                <option value="female">Female</option>
                <option value="Other">Other</option>
              </select>
            </div>
            <div>
              <label class="mb-2.5 block text-base text-black">
                <span>Date of Birth</span>
                <span class="label-required pl-1 text-red-400">*</span>
              </label>
              <div class="w-full">
                <input
                  type="date"
                  name="date_picker_5B058CB5-40F0-479E-A1F4-BC8D63E1DAA4"
                  placeholder="mm/dd/yyyy"
                  class="block w-full rounded border border-stroke bg-white px-5 py-3 text-base text-body-color outline-none focus:border-primary"
                />
              </div>
            </div>
          </div>
        </div>
        
        <div class="SortableItem fb-builder-item">
          <div class="mb-4 flex">
            <div class="mr-4" style={{ marginRight: '10px' }}>
              <label class="mb-2.5 block text-base text-black">
                <span>E-Mail</span>
                <span class="label-required pl-1 text-red-400">*</span>
              </label>
              <input
                type="email"
                class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
                name="email_input_B63DD752-1505-4D4F-8544-1DBDD6122E88"
                placeholder="Enter Email Address"
                required
              />
            </div>
            <div>
              <label class="mb-2.5 block text-base text-black">
                <span>Phone Number</span>
                <span class="label-required pl-1 text-red-400">*</span>
              </label>
              <input
                type="tel"
                class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
                name="phone_input_34A134D4-7D34-45B8-9D7F-5CC08EABEC91"
                placeholder="Phone Number"
                required
              />
            </div>
          </div>
        </div>
        
        <div class="SortableItem fb-builder-item">
          <div class="mb-4">
            <label class="mb-2.5 block text-base text-black"
              ><span>Address</span ><span class="label-required pl-1 text-red-400">*</span></label>
              <textarea
              class="w-full rounded border border-stroke bg-white px-5 py-3 text-base text-black outline-none focus:border-primary"
              name="text_area_C8864360-6C44-4281-AC2D-0951DA105C0B"
              placeholder="Address"
              required
            ></textarea>
          </div>
        </div>
        <div class="SortableItem fb-builder-item">
          <div class="mb-4">
            <div class="custom-control custom-checkbox mb-2.5 last:mb-0">
              <input
                id="fid_preview_checkboxes_option_C979C187-3D44-475D-B8BA-3C7298A3409D"
                class="custom-control-input fb-builder-checkbox sr-only"
                name="option_checkboxes_option_C979C187-3D44-475D-B8BA-3C7298A3409D"
                type="checkbox"
                required
              /><label
                class="custom-control-label relative flex cursor-pointer text-base text-black"
                for="fid_preview_checkboxes_option_C979C187-3D44-475D-B8BA-3C7298A3409D"
                ><span
                  class="relative mr-2.5 mt-0.5 block h-[18px] w-[18px] rounded border border-stroke bg-white"
                  ><span
                    class="absolute left-0 top-0 flex h-full w-full items-center justify-center rounded opacity-0"
                    ><svg
                      width="14"
                      height="14"
                      viewBox="0 0 14 14"
                      fill="none"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <g clip-path="url(#clip0_1981_8153)">
                        <path
                          d="M5.82952 8.85086L11.1915 3.48828L12.0169 4.31311L5.82952 10.5005L2.11719 6.7882L2.94202 5.96336L5.82952 8.85086Z"
                          fill="white"
                        ></path>
                      </g>
                      <defs>
                        <clipPath id="clip0_1981_8153">
                          <rect width="14" height="14" fill="white"></rect>
                        </clipPath>
                      </defs></svg></span></span> I agree - <a style={{color: 'blue'}}href="#">    terms & conditions</a></label >
            </div>
          </div>
        </div>
        <div class="btn-toolbar flex items-center space-x-3">
          <input
            type="submit"
            class="inline-flex cursor-pointer items-center justify-center rounded border border-primary bg-primary px-8 py-2 text-base font-medium text-white hover:bg-opacity-90"
            value="Submit"
          />
        </div>
      </form>
    
    </div>
  </div>
  
  );
}

export default Register;
