import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Signup from './components/Signup';
import Login from './components/Login';
import Register from './components/Register';
import './App.css';

function App() {
  return (
    <Router>
    <div className="inline-links">
  <span>
    <Link to="/Login">Login</Link>
  </span>
  <span style={{ marginLeft: '30px' }}>
    <Link to="/Signup">Signup</Link>
  </span>

  {/* <span style={{ marginLeft: '30px' }}>
    <Link to="/Register">Register</Link>
  </span> */}

  
</div>


      {/* Define React Router routes */}
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/Signup" element={<Signup />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/Register" element={<Register />} />

      </Routes>
    </Router>
  );
}

export default App;
